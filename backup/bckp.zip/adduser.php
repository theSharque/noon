<?php

$good = true;
session_start();

include "./include/misc.inc";
include "./include/db.inc";

function get_out( $err ) {
  header("Location: register.php?err=$err");
  exit();
}

if( count( $_POST ) > 0 ) {
  if( !isset( $_SESSION['captcha_keystring'] ) || $_SESSION['captcha_keystring'] != $_POST['keystring'] ) {
    $good = false;
    get_out( 8 );
  }

  if( !isset( $_POST['login'] ) || strlen( $_POST['login'] ) == 0 ) {
    $good = false;
    get_out( 1 );
  } else {
    $id = db_fetch_val( "SELECT id FROM users WHERE login = '".$_POST['login']."'", 'id' );
    if( $id ) {
      $good = false;
      get_out( 2 );
    } else {
      $login = $_POST['login'];
    }
  }

  if( $_POST['pass1'] != $_POST['pass2'] ) {
    $good = false;
    get_out( 3 );
  }

  if( !isset( $_POST['pass1'] ) || strlen( $_POST['pass1'] ) == 0 ) {
    $good = false;
    get_out( 4 );
  } else {
    $pass1 = $_POST['pass1'];
  }

  if( !isset( $_POST['pass2'] ) || strlen( $_POST['pass2'] ) == 0 ) {
    $good = false;
    get_out( 5 );
  } else {
    $pass2 = $_POST['pass2'];
  }

  if( !isset( $_POST['email'] ) || strlen( $_POST['email'] ) == 0 ) {
    $good = false;
    get_out( 6 );
  } else {
    if( eregi( "^[a-zA-Z0-9_]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+$]", $_POST['email'] ) ) {
      $good = false;
      get_out( 7 );
    } else {
      $email = $_POST['email'];
    }
  }

  if( $good ) {
    db_query( "INSERT INTO users (login, password, email, ssid, lastlogin, status, place_id, place_type, money, credits)
               VALUES ( '$login', '".md5($pass1)."', '$email', 0, 0, 1, 1, 1, 15000, 9 )" );
    $user_id = mysql_insert_id();

    include "./pages/register/gensystem.page";
    GenerateSystem( $user_id );

    header("Location: index.php?l=$login");

    exit();
  }
} else {
  header("Location: register.php");
  exit();
}

unset( $_SESSION['captcha_keystring'] );
