<?php 
     define('_SAPE_USER', '2ecff8ad8e254025ba7b1b60741e1f37');
     require_once($_SERVER['DOCUMENT_ROOT'].'/'._SAPE_USER.'/sape.php'); 
     $sape_articles = new SAPE_articles();
     echo $sape_articles->process_request();
?>
