<?php

  include( "./include/db.inc" );
  include( "./include/misc.inc" );
  do_events();
  
  $page_id = $_GET['id'];

  switch( $page_id ) {
    case 9:
      include './pages/chat/main.page';
      break;
    case 91:
      include './pages/chat/read.page';
      break;
    case 92:
      include './pages/chat/write.page';
      break;
    case 93:
      include './pages/chat/get.page';
      break;
    case 94:
      include './pages/chat/put.page';
      break;
    case 95:
      include './pages/chat/users.page';
      break;

    default :
      print '404 error '.$page_id;
      break;
  }  
