<?php

  include "./include/boot.inc";

  bootup();
  
  header("Cache-Control: no-cache, must-revalidate");
  header("Pragma: no-cache ");

  if( authorization() ) {
  global $user;

    if( isset( $_GET['id'] ) && is_numeric( $_GET['id'] ) ) {
      $page_id = $_GET['id'];
    } else {
      $page_id = '404';
    }

    switch( $page_id ) {
      case 0:
        include './pages/topmenu.page';
        break;

      case 64536:
        include './pages/result.page';
        break;
      case 31522:
        include './pages/success.page';
        break;
      case 74832:
        include './pages/fail.page';
        break;

      case 1:
        do_events();
        authorization();
        include './pages/character/info.page';
        show_tutorial( 1 );
        break;
      case 11:
        include './pages/character/questload.page';
        break;
      case 12:
        include './pages/character/questdesc.page';
        break;
      case 16:
        include './pages/character/queststart.page';
        break;
      case 17:
        include './pages/character/queststop.page';
        break;

      case 121:
        include './pages/character/bookdata.page';
        break;
      case 122:
        do_events();
        authorization();
        include './pages/character/booklearn.page';
        break;
      case 123:
        include './pages/character/bookdesc.page';
        break;
      case 124:
        include './pages/character/bookteach.page';
        break;
      case 125:
        do_events();
        authorization();
        include './pages/character/messages.page';
        break;
      case 126:
        include './pages/character/readmsg.page';
        break;
      case 127:
        include './pages/character/deletemsg.page';
        break;
      case 13:
        include './pages/character/userinfo.page';
        break;
      case 14:
        include './pages/gettutor.page';
        break;
      case 15:
        include './pages/reminder.page';
        break;


      case 2:
        include './pages/environment/place.page';
        show_tutorial( 2 );
        break;
      case 21:
        do_events();
        authorization();
        include './pages/environment/planetmap.page';
        break;

      case 22:
        do_events();
        authorization();
        include './pages/environment/orbitmap.page';
        break;
      case 221:
        include './pages/environment/orbitinfo.page';
        break;
      case 222:
        include './pages/environment/orbituse.page';
        break;
      case 225:
        do_events();
        authorization();
        include './pages/environment/dockme.page';
        break;

      case 23:
        include './pages/environment/station.page';
        break;
      case 231:
        do_events();
        authorization();
        include './pages/environment/tradeinfo.page';
        break;
      case 232:
        include './pages/environment/tradesave.page';
        break;
      case 233:
        do_events();
        authorization();
        include './pages/environment/goods.page';
        break;

      case 240:
        do_events();
        authorization();
        include './pages/environment/gettimer.page';
        break;

      case 25:
        do_events();
        authorization();
        include './pages/environment/startbuild.page';
        break;
      case 26:
        do_events();
        authorization();
        include './pages/environment/panelinfo.page';
        break;
      case 261:
        include './pages/environment/stopthat.page';
        include './pages/environment/destroy.page';
        break;
      case 27:
        do_events();
        authorization();
        include './pages/environment/paneluse.page';
        break;
      case 282:
        include './pages/environment/shiplist.page';
        break;
      case 283:
        include './pages/environment/defence.page';
        break;

      case 28:
        include './pages/environment/listbuild.page';
        break;
      case 29:
        do_events();
        authorization();
        include './pages/environment/listres.page';
        break;
      case 210:
        include './pages/environment/listmines.page';
        break;
      case 211:
        include './pages/environment/startmine.page';
        break;
      case 271:
        do_events();
        authorization();
        include './pages/environment/listdisp.page';
        break;
      case 272:
        do_events();
        authorization();
        include './pages/environment/startdisp.page';
        break;
      case 273:
        do_events();
        authorization();
        include './pages/environment/panelupgrade.page';
        break;
      case 274:
        do_events();
        authorization();
        include './pages/environment/startupgrade.page';
        break;
      case 275:
        do_events();
        authorization();
        include './pages/environment/listmake.page';
        break;
      case 276:
        do_events();
        authorization();
        include './pages/environment/startmake.page';
        break;
      case 277:
        include './pages/environment/stopthat.page';
        break;
      case 278:
        do_events();
        authorization();
        include './pages/environment/listcomp.page';
        break;
      case 279:
        do_events();
        authorization();
        include './pages/environment/startcomp.page';
        break;
      case 280:
        include './pages/environment/listlab.page';
        break;
      case 281:
        include './pages/environment/startlab.page';
        break;

      case 3:
        do_events();
        authorization();
        include './pages/ships/main.page';
        show_tutorial( 3 );
        break;
      case 31:
        do_events();
        authorization();
        include './pages/ships/shipslist.page';
        break;
      case 32:
        do_events();
        authorization();
        include './pages/ships/orderslist.page';
        break;
      case 321:
        do_events();
        authorization();
        include './pages/ships/itemslist.page';
        break;
      case 33:
        do_events();
        authorization();
        include './pages/ships/makeorder.page';
        break;
      case 34:
        include './pages/ships/fleet.page';
        break;
      case 35:
        include './pages/ships/makefleet.page';
        break;
      case 36:
        do_events();
        authorization();
        include './pages/ships/getinfo.page';
        break;
      case 37:
        do_events();
        authorization();
        include './pages/ships/getplanets.page';
        break;
      case 371:
        do_events();
        authorization();
        include './pages/ships/getstars.page';
        break;
      case 372:
        include './pages/ships/starcoord.page';
        break;
      case 373:
        include './pages/ships/starmove.page';
        break;
      case 38:
        do_events();
        authorization();
        include './pages/ships/getcoord.page';
        break;
      case 39:
        do_events();
        authorization();
        include './pages/ships/movecoord.page';
        break;
      case 391:
        include './pages/ships/deconverce.page';
        break;

      case 4:
        do_events();
        authorization();
        include './pages/warehouse/main.page';
        show_tutorial( 4 );
        break;
      case 41:
        do_events();
        authorization();
        include './pages/warehouse/shipslist.page';
        break;
      case 42:
        do_events();
        authorization();
        include './pages/warehouse/shipitems.page';
        break;
      case 43:
        do_events();
        authorization();
        include './pages/warehouse/siloslist.page';
        break;
      case 44:
        do_events();
        authorization();
        include './pages/warehouse/siloitems.page';
        break;
      case 45:
        include './pages/warehouse/moveitem.page';
        break;

      case 5:
        do_events();
        authorization();
        include './pages/trade/main.page';
        show_tutorial( 5 );
        break;
      case 51:
        include './pages/trade/shipslist.page';
        break;
      case 52:
        do_events();
        authorization();
        include './pages/trade/itemslist.page';
        break;
      case 53:
        include './pages/trade/bayitems.page';
        break;
      case 54:
        include './pages/trade/sellitems.page';
        break;

      case 6:
        levelUp( 6, $user->uid );
        do_events();
        authorization();
        include './pages/misc/main.page';
        show_tutorial( 6 );
        break;
      case 61:
        include './pages/misc/itemslist.page';
        break;
      case 62:
        include './pages/misc/iteminfo.page';
        break;
      case 63:
        do_events();
        authorization();
        include './pages/misc/tradelist.page';
        break;
      case 64:
        include './pages/misc/robotslist.page';
        break;
      case 65:
        include './pages/misc/pricelist.page';
        break;
      case 651:
        include './pages/misc/priceinfo.page';
        break;
      case 652:
        include './pages/misc/bayitem.page';
        break;
      case 66:
        include './pages/misc/settings.page';
        break;
      case 67:
        include './pages/misc/savesettings.page';
        break;

      case 7:
        include './pages/exit.page';
        break;

      case 9:
        include './pages/chat/main.page';
        break;
      case 91:
        include './pages/chat/read.page';
        break;
      case 92:
        include './pages/chat/write.page';
        break;
      case 93:
        include './pages/chat/get.page';
        break;
      case 94:
        include './pages/chat/put.page';
        break;
      case 95:
        include './pages/chat/users.page';
        break;

      case 990:
        do_events();
        authorization();
        include './pages/admin/main.page';
        break;
      case 991:
        include './pages/admin/subedit.page';
        break;
      case 992:
        include './pages/admin/objedit.page';
        break;
      case 993:
        include './pages/admin/reguser.page';
        break;
      case 994:
        include './pages/admin/encedit.page';
        break;
      case 995:
        include './pages/admin/enc.page';
        break;
      case 996:
        include './pages/admin/research.page';
        break;
      case 997:
        include './pages/admin/ships.page';
        break;
      case 998:
        include './pages/admin/tutedit.page';
        break;

      default :
        do_events();
        authorization();
        print '404 error '.$page_id;
        break;
    }  
  }