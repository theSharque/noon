<?php
  include "./include/boot.inc";

  bootup();
  
  if( !authorization() ) {
    include "./pages/index.page";
  } else { ?>
<HTML>
<HEAD>
<TITLE>Noon</TITLE>
</HEAD>
<FRAMESET id="noon" rows="20,500,*" border=0 frameborder=no framespacing=0>
  <FRAME src="page.php?id=0" name=topmenu scrolling=no noresize TOPMARGIN=0 LEFTMARGIN=0 MARGINHEIGHT=0 MARGINWIDTH=0>
  <FRAME src="page.php?id=1" name=main scrolling=no noresize TOPMARGIN=0 LEFTMARGIN=0 MARGINHEIGHT=0 MARGINWIDTH=0>
  <FRAME src="page.php?id=9" name=chat scrolling=no noresize TOPMARGIN=0 LEFTMARGIN=0 MARGINHEIGHT=0 MARGINWIDTH=0>
</FRAMESET>
</HTML><?php
  }